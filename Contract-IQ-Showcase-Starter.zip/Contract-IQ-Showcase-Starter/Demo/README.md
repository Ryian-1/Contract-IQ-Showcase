# Application demonstration

Add a short screen recording of the running Contract IQ application and then place its public URL in the root `README.md`.

Suggested walkthrough:

1. Open the application and demonstrate sign-in.
2. Show the Dashboard and Contracts areas.
3. Open a sample contract record.
4. Demonstrate the available Contract Intelligence report.
5. Show the negotiation and lifecycle areas that are available in the current build.
6. Show workspace settings and member-role administration.

Use only fictional or anonymised data. Do not record passwords, authentication tokens, private customer documents or personal information. Clearly distinguish implemented functionality from screens or workflows that are still under development.
