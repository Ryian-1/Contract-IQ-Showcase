# Contract IQ

**End-to-End Contract Lifecycle Management**  
*A native macOS application concept and working development build for structured contract operations.*

Contract IQ is a Contract Lifecycle Management (CLM) application designed to bring contract records, document intake, contract review, risk visibility, negotiation workflows, approvals and post-signature lifecycle activities into one centralised workspace.

It is intended to help organisations reduce fragmented contract administration, improve visibility into contractual issues and obligations, and coordinate responsibilities throughout the contract lifecycle.

> **Showcase repository only:** This repository contains product information and demonstration materials. It intentionally does not contain the Contract IQ application source code, Xcode project, credentials, private configuration files or production customer data. The main source repository is maintained separately and is not part of this showcase.

## Product capabilities

- **Dashboard:** A portfolio-oriented starting point for contract operations.
- **Contract repository:** Contract records, discovery, selection and contract detail views.
- **Contract intake:** A dedicated entry point for incoming contract information and associated documents.
- **Contract intelligence and Risk Centre:** A structured report experience for available clause, risk and obligation findings.
- **Negotiation and redlining workflows:** Change proposals and negotiation status concepts to keep review decisions connected to the agreement.
- **Obligations and lifecycle management:** Concepts for obligations, renewal planning, amendments, termination and lifecycle follow-up.
- **Activity:** An activity-oriented area for operational visibility.
- **Workspace administration:** Settings and member-role administration concepts.

## Contract lifecycle

`Draft → Review → Negotiation → Approved → Signed → Active → Closed`

The precise transitions and operational controls are subject to the application's configured workflow and release testing.

## Technology foundation

| Technology | Role |
|---|---|
| Swift | Application programming language |
| SwiftUI | Native macOS user interface |
| Xcode | Development and build environment |
| Firebase Authentication | Email/password authentication and Google credential sign-in |
| Google Sign-In | Google account authentication |
| Cloud Firestore | Application data persistence in the configured data model |
| Local document services | Contract-linked document operations |

## Screenshots

Application screenshots will be added to [`Screenshots/`](Screenshots/). Only genuine screenshots captured from the running application should be used; conceptual mock-ups should be labelled clearly.

## Demonstration

A recorded application walkthrough can be linked here once prepared. See [`Demo/README.md`](Demo/README.md) for the upload checklist.

## Project documentation

See [`Documentation/`](Documentation/) for the product and technical overview included with this showcase. Detailed internal project documents may be shared separately with authorised academic or review recipients.

## Development status and scope

Contract IQ is a feature-rich macOS development build. Development checks have included successful Xcode builds, confirmation of Google Sign-In after configuration correction, and a structured presentation of analysis results.

The current documented contract-analysis pathway uses basic text-pattern and keyword-based logic. Its findings are intended to support human review; they are not legal advice or a legally validated automated assessment. Production deployment requires further verification of document handling, backend-enforced permissions, data isolation, persistence, backup and recovery, signature-provider integration, end-to-end testing and operational controls.

## Intellectual property and usage

Contract IQ and its application source code are proprietary project work. This showcase is provided for product demonstration and academic evaluation only. No licence to use, reproduce, modify, distribute or commercially exploit the application is granted by viewing this repository. All rights are reserved unless separately agreed in writing.

---

**Project:** Contract IQ  
**Platform:** macOS  
**Primary stack:** Swift · SwiftUI · Firebase
