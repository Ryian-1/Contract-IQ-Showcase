# Application screenshots

Add genuine screenshots captured from the running Contract IQ application. Recommended files:

- `01-login.png`
- `02-dashboard.png`
- `03-contracts.png`
- `04-contract-intake.png`
- `05-contract-intelligence-report.png`
- `06-risk-centre.png`
- `07-negotiation.png`
- `08-obligations.png`
- `09-members-and-permissions.png`

Before publishing, use fictional or anonymised test data. Do not include real customer contracts, personal information, email addresses, authentication tokens, Firebase configuration, API keys or other secrets.

Do not use generated mock-ups as evidence of implemented screens. If you include a conceptual design, label it as a concept.
