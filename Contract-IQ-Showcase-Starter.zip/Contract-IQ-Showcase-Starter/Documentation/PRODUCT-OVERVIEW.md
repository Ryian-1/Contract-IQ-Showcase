# Contract IQ — Product Overview

## Executive summary

Contract IQ is a native macOS Contract Lifecycle Management (CLM) application designed to coordinate contract records, document intake, review intelligence, negotiation activity and post-signature lifecycle management in one contract-centric workspace.

## Business problem

Contract information and actions are often distributed across folders, spreadsheets, email conversations and individual team members. This can make it difficult to confirm the current agreement version, review status, responsible owner, next action, contractual obligations and upcoming notice dates.

Contract IQ is designed to connect these activities to a central contract record and make the contract's operational context easier to inspect.

## Product areas

1. **Dashboard** — portfolio-oriented entry point and operational context.
2. **Contracts** — contract records, selection, creation and detail review.
3. **Contract Intake** — dedicated entry point for incoming agreement information and documents.
4. **Contract Intelligence / Risk Centre** — structured presentation of available analysis results for human review.
5. **Negotiation and Redlining** — proposed change and negotiation-status workflow concepts.
6. **Obligations and Lifecycle** — obligations, renewal planning, amendments, termination and follow-up concepts.
7. **Activity** — activity-oriented operational visibility.
8. **Settings and Members & Permissions** — workspace configuration and member-role administration concepts.

## End-to-end lifecycle model

Draft → Review → Negotiation → Approved → Signed → Active → Closed.

## Intended value

- Reduce fragmentation between contract records and related work.
- Improve visibility into review status, potential issues and follow-up activities.
- Connect negotiation decisions to the relevant agreement.
- Give teams a more structured view of obligations and lifecycle events.
- Establish a foundation for more consistent contract operations.

## Important scope note

The current analysis pathway uses basic text-pattern and keyword-based logic. It is not a legally validated AI system and does not replace qualified legal review. The product remains a development build; production readiness requires security, data isolation, document lifecycle, persistence, recovery and end-to-end validation.
