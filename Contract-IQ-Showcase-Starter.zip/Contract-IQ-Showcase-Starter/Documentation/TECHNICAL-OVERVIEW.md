# Contract IQ — Technical Overview

## Platform

Contract IQ is currently a native macOS application built with Apple's development ecosystem.

## Technology stack

- **Swift:** Application logic and data handling.
- **SwiftUI:** Views, forms, navigation and interface state.
- **AppKit:** macOS-specific window integration used in the Google Sign-In presentation path.
- **Xcode:** Project configuration, builds, debugging and runtime testing.
- **Firebase Core:** Firebase initialisation.
- **Firebase Authentication:** Email/password and Firebase credential sign-in.
- **Google Sign-In SDK:** Google identity sign-in.
- **Cloud Firestore:** Application data persistence within the configured data model.
- **Local document services:** Contract-linked local document operations.

## Logical architecture

1. **Presentation:** SwiftUI screens, navigation and forms.
2. **Application coordination:** Contract stores, workflow coordination and task concepts.
3. **Domain services:** Contract analysis and document operations.
4. **Platform services:** Firebase identity and data services, Google identity and local files.

## Identity and workspace roles

The project includes Firebase email/password authentication and Google Sign-In. Workspace role concepts include Owner, Admin, Legal, Reviewer and Viewer.

Role labels and interface controls are not, by themselves, a security boundary. Backend authorisation must be enforced and tested through Firestore Security Rules or trusted services.

## Release-readiness boundaries

Before production use, validate:

- user and organisation data isolation;
- backend-enforced access control for every role;
- document storage, access, versioning, retention and deletion;
- persistence after restart and network recovery;
- retry and partial-failure handling;
- signature workflow and signed-document evidence;
- automated regression and end-to-end tests;
- backup, restore and operational monitoring.

This overview describes the project's documented technical foundation. It is not an independent security audit or production certification.
