# Proprietary project notice

This repository is a code-free showcase for Contract IQ. It is intended for product demonstration and academic evaluation. The application source code and private project configuration are maintained separately and are not distributed here.

No permission to reproduce, modify, redistribute or commercially exploit Contract IQ is granted by access to this showcase. All rights are reserved unless separately agreed in writing.
